const { axios } = require("./axios");

MicroModal.init();
addJSONEditor();
function openAdd(id) {
  MicroModal.show(id);
}

function addJSONEditor() {
  const container = document.getElementById("jsoneditor");
  const options = {};
  //const editor = new JSONEditor(container, options);

  // set json
  const initialJson = {};
  editor.set(initialJson);

  // get json
  const updatedJson = editor.get();
}

function ajaxCall() {}

function createMock() {
  alert();
  console.log(arguments);
  const formRef = document.getElementsByTagName("form")[0];
  let formData = new FormData(formRef);
  console.log(formData.get("testname"));
  let data = {
    testname: formData.get("testname"),
    url: formData.get("url"),
    data: formData.get("jsondata"),
    method: formData.get("method"),
  };
  console.log(data);

  axios
    .post("/api/v1/createMock", data)
    .then((response) => {
      alert(response);
    })
    .catch((e) => {
      alert(e);
    });
}

function deleteMock(id) {
  axios
    .delete(id)
    .then((response) => {
      console.log(response);
    })
    .err((err) => {});
}

ajaxCall();
